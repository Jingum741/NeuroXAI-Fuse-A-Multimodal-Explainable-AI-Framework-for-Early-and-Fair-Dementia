#!/usr/bin/env python3
"""
NeuroXAI-Fuse: Complete Experiment Runner
This script orchestrates the entire experimental pipeline from data loading to results generation.
"""

import os
import sys
import json
import argparse
import warnings
from datetime import datetime
from pathlib import Path
import torch
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
import logging

# Import our modules
from neuroxai_model import NeuroXAIFuse, get_model_config
from data_preprocessing import create_data_loaders, ADNIDataPreprocessor, analyze_dataset_distribution
from training_script import ModelTrainer, create_training_config
from evaluation_metrics import ComprehensiveEvaluator
from visualization_plots import NeuroXAIVisualizer

warnings.filterwarnings('ignore')

class ExperimentRunner:
    """Main experiment orchestrator for NeuroXAI-Fuse"""
    
    def __init__(self, config_file: str = None):
        """Initialize experiment runner with configuration"""
        
        # Load configuration
        if config_file and os.path.exists(config_file):
            with open(config_file, 'r') as f:
                self.config = json.load(f)
        else:
            self.config = self.create_default_config()
        
        # Setup experiment directory
        self.experiment_dir = Path(self.config['experiment']['output_dir'])
        self.experiment_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        self.setup_logging()
        
        # Initialize components
        self.model = None
        self.trainer = None
        self.evaluator = None
        self.visualizer = None
        
        self.logger.info(f"Experiment initialized: {self.experiment_dir}")
        self.logger.info(f"Configuration: {json.dumps(self.config, indent=2)}")
    
    def create_default_config(self):
        """Create default experimental configuration"""
        return {
            "experiment": {
                "name": "neuroxai_fuse_experiment",
                "output_dir": f"./experiments/run_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "seed": 42,
                "device": "cuda" if torch.cuda.is_available() else "cpu"
            },
            "data": {
                "data_dir": "./data/ADNI",
                "n_subjects": 1000,
                "batch_size": 16,
                "test_size": 0.2,
                "val_size": 0.1,
                "cross_validation": {
                    "enabled": False,
                    "n_folds": 5
                }
            },
            "model": {
                **get_model_config(),
                "checkpoint_path": None  # Path to resume from checkpoint
            },
            "training": {
                "epochs": 100,
                "learning_rate": 0.001,
                "min_lr": 1e-6,
                "weight_decay": 1e-4,
                "early_stopping_patience": 20,
                "save_every": 10,
                "validate_every": 1
            },
            "evaluation": {
                "metrics": [
                    "accuracy", "precision", "recall", "f1_score", "auc",
                    "fairness", "interpretability", "uncertainty"
                ],
                "generate_plots": True,
                "save_predictions": True,
                "comparison_baselines": [
                    "3D_CNN", "MultiModal_CNN", "Attention_CNN", "Transformer_XAI"
                ]
            },
            "logging": {
                "use_wandb": True,
                "wandb_project": "neuroxai-fuse",
                "log_level": "INFO"
            }
        }
    
    def setup_logging(self):
        """Setup experiment logging"""
        log_level = getattr(logging, self.config['logging']['log_level'])
        
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.experiment_dir / 'experiment.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        
        self.logger = logging.getLogger('NeuroXAI-Experiment')
    
    def set_seed(self, seed: int = None):
        """Set random seeds for reproducibility"""
        if seed is None:
            seed = self.config['experiment']['seed']
        
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        
        self.logger.info(f"Random seed set to: {seed}")
    
    def load_data(self):
        """Load and prepare datasets"""
        self.logger.info("Loading and preparing datasets...")
        
        data_config = self.config['data']
        
        # Create data loaders
        self.train_loader, self.val_loader, self.test_loader = create_data_loaders(
            data_dir=data_config['data_dir'],
            batch_size=data_config['batch_size'],
            n_subjects=data_config['n_subjects'],
            test_size=data_config['test_size'],
            val_size=data_config['val_size']
        )
        
        # Analyze dataset distribution
        preprocessor = ADNIDataPreprocessor(data_config['data_dir'])
        clinical_data = preprocessor.create_dummy_clinical_data(data_config['n_subjects'])
        clinical_data = preprocessor.demographic_correction(clinical_data)
        
        self.dataset_stats = analyze_dataset_distribution(clinical_data)
        
        # Save dataset statistics
        dataset_info = {
            'train_batches': len(self.train_loader),
            'val_batches': len(self.val_loader),
            'test_batches': len(self.test_loader),
            'total_subjects': data_config['n_subjects']
        }
        
        with open(self.experiment_dir / 'dataset_info.json', 'w') as f:
            json.dump(dataset_info, f, indent=2)
        
        self.logger.info(f"Data loaded: {dataset_info}")
    
    def create_model(self):
        """Create and initialize model"""
        self.logger.info("Creating NeuroXAI-Fuse model...")
        
        model_config = self.config['model']
        self.model = NeuroXAIFuse(model_config)
        
        # Load checkpoint if specified
        if model_config.get('checkpoint_path') and os.path.exists(model_config['checkpoint_path']):
            checkpoint = torch.load(model_config['checkpoint_path'])
            self.model.load_state_dict(checkpoint['model_state_dict'])
            self.logger.info(f"Loaded checkpoint from: {model_config['checkpoint_path']}")
        
        # Move to device