import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau
import numpy as np
import os
import json
import logging
from datetime import datetime
from tqdm import tqdm
import wandb
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Tuple

# Import our modules
from neuroxai_model import NeuroXAIFuse, get_model_config
from data_preprocessing import create_data_loaders, analyze_dataset_distribution

class TrainingLogger:
    """Enhanced logging for training process"""
    
    def __init__(self, log_dir: str, use_wandb: bool = True, project_name: str = "NeuroXAI-Fuse"):
        self.log_dir = log_dir
        self.use_wandb = use_wandb
        
        # Create directories
        os.makedirs(log_dir, exist_ok=True)
        os.makedirs(os.path.join(log_dir, 'checkpoints'), exist_ok=True)
        os.makedirs(os.path.join(log_dir, 'plots'), exist_ok=True)
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(log_dir, 'training.log')),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # Initialize wandb
        if self.use_wandb:
            wandb.init(project=project_name, dir=log_dir)
        
        # Training metrics storage
        self.train_metrics = {
            'loss': [], 'accuracy': [], 'auc': [],
            'pred_loss': [], 'dp_loss': [], 'eo_loss': [], 'adv_loss': []
        }
        self.val_metrics = {
            'loss': [], 'accuracy': [], 'auc': [],
            'pred_loss': [], 'dp_loss': [], 'eo_loss': [], 'adv_loss': []
        }
        self.learning_rates = []
        
    def log_epoch(self, epoch: int, train_metrics: Dict, val_metrics: Dict, lr: float):
        """Log metrics for an epoch"""
        # Store metrics
        for key in self.train_metrics:
            if key in train_metrics:
                self.train_metrics[key].append(train_metrics[key])
        
        for key in self.val_metrics:
            if key in val_metrics:
                self.val_metrics[key].append(val_metrics[key])
        
        self.learning_rates.append(lr)
        
        # Log to console
        self.logger.info(f"Epoch {epoch:03d} - "
                        f"Train Loss: {train_metrics['loss']:.4f}, "
                        f"Train Acc: {train_metrics['accuracy']:.4f}, "
                        f"Val Loss: {val_metrics['loss']:.4f}, "
                        f"Val Acc: {val_metrics['accuracy']:.4f}, "
                        f"LR: {lr:.6f}")
        
        # Log to wandb
        if self.use_wandb:
            log_dict = {
                'epoch': epoch,
                'learning_rate': lr,
                'train/loss': train_metrics['loss'],
                'train/accuracy': train_metrics['accuracy'],
                'train/auc': train_metrics.get('auc', 0),
                'val/loss': val_metrics['loss'],
                'val/accuracy': val_metrics['accuracy'],
                'val/auc': val_metrics.get('auc', 0),
            }
            
            # Add loss components
            for component in ['pred_loss', 'dp_loss', 'eo_loss', 'adv_loss']:
                if component in train_metrics:
                    log_dict[f'train/{component}'] = train_metrics[component]
                if component in val_metrics:
                    log_dict[f'val/{component}'] = val_metrics[component]
            
            wandb.log(log_dict)
    
    def save_metrics(self):
        """Save metrics to file"""
        metrics = {
            'train_metrics': self.train_metrics,
            'val_metrics': self.val_metrics,
            'learning_rates': self.learning_rates
        }
        
        with open(os.path.join(self.log_dir, 'training_metrics.json'), 'w') as f:
            json.dump(metrics, f, indent=2)
    
    def plot_training_curves(self):
        """Plot and save training curves"""
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # Loss curves
        axes[0, 0].plot(self.train_metrics['loss'], label='Train', alpha=0.8)
        axes[0, 0].plot(self.val_metrics['loss'], label='Validation', alpha=0.8)
        axes[0, 0].set_title('Total Loss')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # Accuracy curves
        axes[0, 1].plot(self.train_metrics['accuracy'], label='Train', alpha=0.8)
        axes[0, 1].plot(self.val_metrics['accuracy'], label='Validation', alpha=0.8)
        axes[0, 1].set_title('Accuracy')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Accuracy')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
        
        # AUC curves
        axes[0, 2].plot(self.train_metrics['auc'], label='Train', alpha=0.8)
        axes[0, 2].plot(self.val_metrics['auc'], label='Validation', alpha=0.8)
        axes[0, 2].set_title('AUC Score')
        axes[0, 2].set_xlabel('Epoch')
        axes[0, 2].set_ylabel('AUC')
        axes[0, 2].legend()
        axes[0, 2].grid(True, alpha=0.3)
        
        # Loss components
        loss_components = ['pred_loss', 'dp_loss', 'eo_loss']
        for i, component in enumerate(loss_components):
            if component in self.train_metrics and len(self.train_metrics[component]) > 0:
                axes[1, i].plot(self.train_metrics[component], label='Train', alpha=0.8)
                axes[1, i].plot(self.val_metrics[component], label='Validation', alpha=0.8)
                axes[1, i].set_title(f'{component.replace("_", " ").title()}')
                axes[1, i].set_xlabel('Epoch')
                axes[1, i].set_ylabel('Loss')
                axes[1, i].legend()
                axes[1, i].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.log_dir, 'plots', 'training_curves.png'), dpi=300, bbox_inches='tight')
        plt.close()
        
        # Learning rate schedule
        plt.figure(figsize=(10, 6))
        plt.plot(self.learning_rates)
        plt.title('Learning Rate Schedule')
        plt.xlabel('Epoch')
        plt.ylabel('Learning Rate')
        plt.yscale('log')
        plt.grid(True, alpha=0.3)
        plt.savefig(os.path.join(self.log_dir, 'plots', 'learning_rate.png'), dpi=300, bbox_inches='tight')
        plt.close()

class ModelTrainer:
    """Main trainer class for NeuroXAI-Fuse"""
    
    def __init__(self, 
                 model: nn.Module,
                 train_loader,
                 val_loader,
                 test_loader,
                 config: Dict,
                 log_dir: str):
        
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        self.config = config
        self.log_dir = log_dir
        
        # Setup device
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        
        # Setup optimizer
        self.optimizer = optim.Adam(
            self.model.parameters(),
            lr=config.get('learning_rate', 0.001),
            weight_decay=config.get('weight_decay', 0.0001)
        )
        
        # Setup scheduler
        self.scheduler = CosineAnnealingLR(
            self.optimizer,
            T_max=config.get('epochs', 100),
            eta_min=config.get('min_lr', 1e-6)
        )
        
        # Early stopping
        self.early_stopping_patience = config.get('early_stopping_patience', 20)
        self.best_val_auc = 0.0
        self.best_epoch = 0
        self.patience_counter = 0
        
        # Initialize logger
        self.logger = TrainingLogger(log_dir, use_wandb=config.get('use_wandb', True))
        
        print(f"Training on device: {self.device}")
        print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    def train_epoch(self) -> Dict:
        """Train for one epoch"""
        self.model.train()
        
        total_loss = 0
        total_pred_loss = 0
        total_dp_loss = 0
        total_eo_loss = 0
        total_adv_loss = 0
        
        all_predictions = []
        all_labels = []
        all_probs = []
        
        pbar = tqdm(self.train_loader, desc="Training")
        
        for batch_idx, batch in enumerate(pbar):
            # Move data to device
            for key in batch:
                if isinstance(batch[key], torch.Tensor):
                    batch[key] = batch[key].to(self.device)
            
            # Forward pass
            self.optimizer.zero_grad()
            outputs = self.model(batch, compute_loss=True)
            
            # Backward pass
            loss = outputs['loss']
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            
            self.optimizer.step()
            
            # Accumulate metrics
            total_loss += loss.item()
            loss_dict = outputs['loss_dict']
            total_pred_loss += loss_dict['pred_loss']
            total_dp_loss += loss_dict['dp_loss']
            total_eo_loss += loss_dict['eo_loss']
            total_adv_loss += loss_dict['adv_loss']
            
            # Collect predictions for metrics
            predictions = outputs['predictions'].argmax(dim=1).cpu().numpy()
            labels = batch['labels'].cpu().numpy()
            probs = torch.softmax(outputs['predictions'], dim=1).cpu().numpy()
            
            all_predictions.extend(predictions)
            all_labels.extend(labels)
            all_probs.extend(probs)
            
            # Update progress bar
            pbar.set_postfix({
                'Loss': f"{loss.item():.4f}",
                'Pred': f"{loss_dict['pred_loss']:.4f}",
                'DP': f"{loss_dict['dp_loss']:.4f}",
                'EO': f"{loss_dict['eo_loss']:.4f}"
            })
        
        # Calculate epoch metrics
        n_batches = len(self.train_loader)
        epoch_metrics = {
            'loss': total_loss / n_batches,
            'pred_loss': total_pred_loss / n_batches,
            'dp_loss': total_dp_loss / n_batches,
            'eo_loss': total_eo_loss / n_batches,
            'adv_loss': total_adv_loss / n_batches,
            'accuracy': accuracy_score(all_labels, all_predictions),
            'auc': roc_auc_score(all_labels, all_probs, multi_class='ovr', average='weighted')
        }
        
        return epoch_metrics
    
    def validate_epoch(self) -> Dict:
        """Validate for one epoch"""
        self.model.eval()
        
        total_loss = 0
        total_pred_loss = 0
        total_dp_loss = 0
        total_eo_loss = 0
        total_adv_loss = 0
        
        all_predictions = []
        all_labels = []
        all_probs = []
        all_concepts = []
        all_responsibilities = []
        
        with torch.no_grad():
            pbar = tqdm(self.val_loader, desc="Validation")
            
            for batch in pbar:
                # Move data to device
                for key in batch:
                    if isinstance(batch[key], torch.Tensor):
                        batch[key] = batch[key].to(self.device)
                
                # Forward pass
                outputs = self.model(batch, compute_loss=True)
                
                # Accumulate metrics
                loss = outputs['loss']
                total_loss += loss.item()
                
                loss_dict = outputs['loss_dict']
                total_pred_loss += loss_dict['pred_loss']
                total_dp_loss += loss_dict['dp_loss']
                total_eo_loss += loss_dict['eo_loss']
                total_adv_loss += loss_dict['adv_loss']
                
                # Collect predictions for metrics
                predictions = outputs['predictions'].argmax(dim=1).cpu().numpy()
                labels = batch['labels'].cpu().numpy()
                probs = torch.softmax(outputs['predictions'], dim=1).cpu().numpy()
                concepts = outputs['concepts'].cpu().numpy()
                responsibilities = outputs['responsibility_scores'].cpu().numpy()
                
                all_predictions.extend(predictions)
                all_labels.extend(labels)
                all_probs.extend(probs)
                all_concepts.extend(concepts)
                all_responsibilities.extend(responsibilities)
                
                pbar.set_postfix({'Loss': f"{loss.item():.4f}"})
        
        # Calculate epoch metrics
        n_batches = len(self.val_loader)
        epoch_metrics = {
            'loss': total_loss / n_batches,
            'pred_loss': total_pred_loss / n_batches,
            'dp_loss': total_dp_loss / n_batches,
            'eo_loss': total_eo_loss / n_batches,
            'adv_loss': total_adv_loss / n_batches,
            'accuracy': accuracy_score(all_labels, all_predictions),
            'auc': roc_auc_score(all_labels, all_probs, multi_class='ovr', average='weighted'),
            'concepts': np.array(all_concepts),
            'responsibilities': np.array(all_responsibilities)
        }
        
        return epoch_metrics
    
    def save_checkpoint(self, epoch: int, is_best: bool = False):
        """Save model checkpoint"""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'best_val_auc': self.best_val_auc,
            'config': self.config
        }
        
        checkpoint_path = os.path.join(self.log_dir, 'checkpoints', f'checkpoint_epoch_{epoch}.pth')
        torch.save(checkpoint, checkpoint_path)
        
        if is_best:
            best_path = os.path.join(self.log_dir, 'checkpoints', 'best_model.pth')
            torch.save(checkpoint, best_path)
            print(f"Saved best model at epoch {epoch} with AUC: {self.best_val_auc:.4f}")
    
    def load_checkpoint(self, checkpoint_path: str):
        """Load model checkpoint"""
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        self.best_val_auc = checkpoint['best_val_auc']
        
        return checkpoint['epoch']
    
    def train(self, epochs: int):
        """Main training loop"""
        print(f"Starting training for {epochs} epochs...")
        
        for epoch in range(1, epochs + 1):
            # Train epoch
            train_metrics = self.train_epoch()
            
            # Validation epoch
            val_metrics = self.validate_epoch()
            
            # Update scheduler
            self.scheduler.step()
            current_lr = self.optimizer.param_groups[0]['lr']
            
            # Log metrics
            self.logger.log_epoch(epoch, train_metrics, val_metrics, current_lr)
            
            # Check for best model
            val_auc = val_metrics['auc']
            is_best = val_auc > self.best_val_auc
            
            if is_best:
                self.best_val_auc = val_auc
                self.best_epoch = epoch
                self.patience_counter = 0
            else:
                self.patience_counter += 1
            
            # Save checkpoint
            if epoch % 10 == 0 or is_best:
                self.save_checkpoint(epoch, is_best)
            
            # Early stopping
            if self.patience_counter >= self.early_stopping_patience:
                print(f"Early stopping at epoch {epoch