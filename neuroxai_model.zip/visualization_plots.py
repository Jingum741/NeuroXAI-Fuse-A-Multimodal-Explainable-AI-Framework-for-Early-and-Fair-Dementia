import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, precision_recall_curve, confusion_matrix
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

class NeuroXAIVisualizer:
    """Comprehensive visualization suite for NeuroXAI-Fuse results"""
    
    def __init__(self, save_dir: str = "./plots", dpi: int = 300):
        self.save_dir = save_dir
        self.dpi = dpi
        
        # Create save directory
        import os
        os.makedirs(save_dir, exist_ok=True)
        
        # Color schemes
        self.class_colors = ['#1f77b4', '#ff7f0e', '#2ca02c']  # CN, MCI, AD
        self.group_colors = sns.color_palette("Set2", 6)  # For demographic groups
        
        # Font settings
        plt.rcParams.update({
            'font.size': 12,
            'axes.labelsize': 14,
            'axes.titlesize': 16,
            'xtick.labelsize': 11,
            'ytick.labelsize': 11,
            'legend.fontsize': 12,
            'figure.titlesize': 18
        })
    
    def plot_roc_curves(self, labels, probabilities, class_names=['CN', 'MCI', 'AD']):
        """Plot ROC curves for multi-class classification"""
        from sklearn.metrics import roc_curve, auc
        from sklearn.preprocessing import label_binarize
        
        # Binarize labels for multi-class ROC
        labels_bin = label_binarize(labels, classes=[0, 1, 2])
        n_classes = labels_bin.shape[1]
        
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Plot ROC curve for each class
        for i in range(n_classes):
            fpr, tpr, _ = roc_curve(labels_bin[:, i], probabilities[:, i])
            roc_auc = auc(fpr, tpr)
            
            ax.plot(fpr, tpr, color=self.class_colors[i], lw=2,
                   label=f'{class_names[i]} (AUC = {roc_auc:.3f})')
        
        # Plot diagonal line
        ax.plot([0, 1], [0, 1], color='gray', lw=2, linestyle='--', alpha=0.8)
        
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        ax.set_xlabel('False Positive Rate')
        ax.set_ylabel('True Positive Rate')
        ax.set_title('Receiver Operating Characteristic (ROC) Curves')
        ax.legend(loc="lower right")
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(f"{self.save_dir}/roc_curves.png", dpi=self.dpi, bbox_inches='tight')
        plt.close()
    
    def plot_confusion_matrix(self, labels, predictions, class_names=['CN', 'MCI', 'AD']):
        """Plot confusion matrix with annotations"""
        cm = confusion_matrix(labels, predictions)
        
        # Normalize confusion matrix
        cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Raw counts
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=class_names, yticklabels=class_names,
                   ax=ax1, cbar_kws={'label': 'Count'})
        ax1.set_title('Confusion Matrix (Counts)')
        ax1.set_xlabel('Predicted Label')
        ax1.set_ylabel('True Label')
        
        # Normalized
        sns.heatmap(cm_normalized, annot=True, fmt='.3f', cmap='Blues',
                   xticklabels=class_names, yticklabels=class_names,
                   ax=ax2, cbar_kws={'label': 'Proportion'})
        ax2.set_title('Confusion Matrix (Normalized)')
        ax2.set_xlabel('Predicted Label')
        ax2.set_ylabel('True Label')
        
        plt.tight_layout()
        plt.savefig(f"{self.save_dir}/confusion_matrix.png", dpi=self.dpi, bbox_inches='tight')
        plt.close()
    
    def plot_fairness_analysis(self, evaluation_results):
        """Plot comprehensive fairness analysis"""
        fairness_data = evaluation_results['fairness']
        group_metrics = fairness_data['group_metrics']
        
        # Extract group performance data
        groups = list(group_metrics.keys())
        accuracies = [group_metrics[g]['accuracy'] for g in groups]
        f1_scores = [group_metrics[g]['f1'] for g in groups]
        counts = [group_metrics[g]['count'] for g in groups]
        
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
        
        # Accuracy by group
        bars1 = ax1.bar(groups, accuracies, color=self.group_colors[:len(groups)], alpha=0.8)
        ax1.set_title('Diagnostic Accuracy by Demographic Group')
        ax1.set_xlabel('Demographic Group')
        ax1.set_ylabel('Accuracy')
        ax1.tick_params(axis='x', rotation=45)
        ax1.grid(True, alpha=0.3)
        
        # Add value labels on bars
        for bar, acc in zip(bars1, accuracies):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + 0.005,
                    f'{acc:.3f}', ha='center', va='bottom')
        
        # F1 scores by group
        bars2 = ax2.bar(groups, f1_scores, color=self.group_colors[:len(groups)], alpha=0.8)
        ax2.set_title('F1-Score by Demographic Group')
        ax2.set_xlabel('Demographic Group')
        ax2.set_ylabel('F1-Score')
        ax2.tick_params(axis='x', rotation=45)
        ax2.grid(True, alpha=0.3)
        
        for bar, f1 in zip(bars2, f1_scores):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height + 0.005,
                    f'{f1:.3f}', ha='center', va='bottom')
        
        # Sample counts by group
        bars3 = ax3.bar(groups, counts, color=self.group_colors[:len(groups)], alpha=0.8)
        ax3.set_title('Sample Count by Demographic Group')
        ax3.set_xlabel('Demographic Group')
        ax3.set_ylabel('Count')
        ax3.tick_params(axis='x', rotation=45)
        ax3.grid(True, alpha=0.3)
        
        for bar, count in zip(bars3, counts):
            height = bar.get_height()
            ax3.text(bar.get_x() + bar.get_width()/2., height + 0.5,
                    f'{count}', ha='center', va='bottom')
        
        # Fairness metrics summary
        fairness_metrics = ['Demographic Parity', 'Equalized Odds', 'Accuracy Gap']
        fairness_values = [
            fairness_data['demographic_parity'],
            fairness_data['equalized_odds'],
            fairness_data['accuracy_gap']
        ]
        
        bars4 = ax4.bar(fairness_metrics, fairness_values, color=['#e74c3c', '#f39c12', '#9b59b6'], alpha=0.8)
        ax4.set_title('Fairness Violation Metrics')
        ax4.set_xlabel('Fairness Metric')
        ax4.set_ylabel('Violation Score (Lower is Better)')
        ax4.tick_params(axis='x', rotation=0)
        ax4.grid(True, alpha=0.3)
        
        for bar, val in zip(bars4, fairness_values):
            height = bar.get_height()
            ax4.text(bar.get_x() + bar.get_width()/2., height + 0.001,
                    f'{val:.4f}', ha='center', va='bottom')
        
        plt.tight_layout()
        plt.savefig(f"{self.save_dir}/fairness_analysis.png", dpi=self.dpi, bbox_inches='tight')
        plt.close()
    
    def plot_concept_analysis(self, concepts, labels, concept_names, class_names=['CN', 'MCI', 'AD']):
        """Plot concept activation analysis"""
        n_concepts = len(concept_names)
        n_classes = len(class_names)
        
        # Calculate average concept activations per class
        concept_by_class = np.zeros((n_classes, n_concepts))
        
        for class_idx in range(n_classes):
            mask = (labels == class_idx)
            if mask.sum() > 0:
                concept_by_class[class_idx] = concepts[mask].mean(axis=0)
        
        # Create heatmap
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 12))
        
        # Concept activation heatmap
        sns.heatmap(concept_by_class, 
                   xticklabels=[name.replace(' ', '\n') for name in concept_names],
                   yticklabels=class_names,
                   annot=True, fmt='.3f', cmap='RdYlBu_r',
                   ax=ax1, cbar_kws={'label': 'Average Activation'})
        ax1.set_title('Average Concept Activations by Diagnosis')
        ax1.set_xlabel('Clinical Concepts')
        ax1.set_ylabel('Diagnosis')
        
        # Concept discrimination (difference between max and min class activations)
        concept_discrimination = np.max(concept_by_class, axis=0) - np.min(concept_by_class, axis=0)
        
        bars = ax2.barh(range(n_concepts), concept_discrimination, color='steelblue', alpha=0.8)
        ax2.set_yticks(range(n_concepts))
        ax2.set_yticklabels([name.replace(' ', '\n') for name in concept_names])
        ax2.set_xlabel('Discrimination Score (Max - Min Activation)')
        ax2.set_title('Concept Discrimination Across Diagnoses')
        ax2.grid(True, alpha=0.3)
        
        # Add value labels
        for i, (bar, score) in enumerate(zip(bars, concept_discrimination)):
            width = bar.get_width()
            ax2.text(width + 0.01, bar.get_y() + bar.get_height()/2,
                    f'{score:.3f}', ha='left', va='center')
        
        plt.tight_layout()
        plt.savefig(f"{self.save_dir}/concept_analysis.png", dpi=self.dpi, bbox_inches='tight')
        plt.close()
    
    def plot_uncertainty_analysis(self, probabilities, labels, responsibilities):
        """Plot uncertainty and responsibility analysis"""
        # Calculate prediction confidence
        confidences = np.max(probabilities, axis=1)
        correct_predictions = (np.argmax(probabilities, axis=1) == labels)
        
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
        
        # Confidence distribution
        ax1.hist(confidences[correct_predictions], bins=30, alpha=0.7, 
                label='Correct', color='green', density=True)
        ax1.hist(confidences[~correct_predictions], bins=30, alpha=0.7,
                label='Incorrect', color='red', density=True)
        ax1.set_xlabel('Prediction Confidence')
        ax1.set_ylabel('Density')
        ax1.set_title('Confidence Distribution by Correctness')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Responsibility score distribution
        ax2.hist(responsibilities, bins=30, alpha=0.8, color='steelblue', density=True)
        ax2.axvline(x=0.8, color='red', linestyle='--', label='High Confidence Threshold')
        ax2.axvline(x=0.5, color='orange', linestyle='--', label='Expert Review Threshold')
        ax2.set_xlabel('Responsibility Score')
        ax2.set_ylabel('Density')
        ax2.set_title('Responsibility Score Distribution')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # Confidence vs Accuracy (binned)
        confidence_bins = np.linspace(0, 1, 11)
        bin_centers = (confidence_bins[:-1] + confidence_bins[1:]) / 2
        bin_accuracies = []
        bin_counts = []
        
        for i in range(len(confidence_bins) - 1):
            mask = (confidences >= confidence_bins[i]) & (confidences < confidence_bins[i+1])
            if mask.sum() > 0:
                bin_accuracies.append(correct_predictions[mask].mean())
                bin_counts.append(mask.sum())
            else:
                bin_accuracies.append(0)
                bin_counts.append(0)
        
        ax3.plot([0, 1], [0, 1], 'k--', alpha=0.5, label='Perfect Calibration')
        ax3.plot(bin_centers, bin_accuracies, 'o-', color='blue', markersize=8, label='Model')
        ax3.set_xlabel('Confidence')
        ax3.set_ylabel('Accuracy')
        ax3.set_title('Reliability Diagram')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        ax3.set_xlim([0, 1])
        ax3.set_ylim([0, 1])
        
        # Responsibility vs Confidence scatter
        scatter = ax4.scatter(confidences, responsibilities, c=correct_predictions.astype(int),
                            cmap='RdYlGn', alpha=0.6, s=20)
        ax4.set_xlabel('Prediction Confidence')
        ax4.set_ylabel('Responsibility Score')
        ax4.set_title('Confidence vs Responsibility')
        ax4.grid(True, alpha=0.3)
        
        # Add colorbar
        cbar = plt.colorbar(scatter, ax=ax4)
        cbar.set_label('Correct Prediction')
        cbar.set_ticks([0, 1])
        cbar.set_ticklabels(['Incorrect', 'Correct'])
        
        plt.tight_layout()
        plt.savefig(f"{self.save_dir}/uncertainty_analysis.png", dpi=self.dpi, bbox_inches='tight')
        plt.close()
    
    def plot_feature_analysis(self, features, labels, method='tsne'):
        """Plot feature space analysis using dimensionality reduction"""
        if method == 'tsne':
            reducer = TSNE(n_components=2, random_state=42, perplexity=30)
            title = 't-SNE'
        else:
            reducer = PCA(n_components=2, random_state=42)
            title = 'PCA'
        
        # Reduce dimensionality
        features_2d = reducer.fit_transform(features)
        
        fig, ax = plt.subplots(figsize=(10, 8))
        
        class_names = ['CN', 'MCI', 'AD']
        for i, (class_name, color) in enumerate(zip(class_names, self.class_colors)):
            mask = (labels == i)
            ax.scatter(features_2d[mask, 0], features_2d[mask, 1],
                      c=color, label=class_name, alpha=0.7, s=30)
        
        ax.set_xlabel(f'{title} Component 1')
        ax.set_ylabel(f'{title} Component 2')
        ax.set_title(f'Feature Space Visualization ({title})')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(f"{self.save_dir}/feature_analysis_{method.lower()}.png", 
                   dpi=self.dpi, bbox_inches='tight')
        plt.close()
    
    def plot_training_dynamics(self, metrics_dict):
        """Plot comprehensive training dynamics"""
        train_metrics = metrics_dict['train_metrics']
        val_metrics = metrics_dict['val_metrics']
        learning_rates = metrics_dict['learning_rates']
        
        epochs = range(1, len(train_metrics['loss']) + 1)
        
        fig = plt.figure(figsize=(20, 12))
        
        # Create subplot grid
        gs = fig.add_gridspec(3, 2, height_ratios=[1, 1, 1], hspace=0.3, wspace=0.3)
        
        # Loss curves
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.plot(epochs, train_metrics['loss'], label='Train', alpha=0.8, linewidth=2)
        ax1.plot(epochs, val_metrics['loss'], label='Validation', alpha=0.8, linewidth=2)
        ax1.set_title('Training and Validation Loss')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Loss')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Accuracy curves
        ax2 = fig.add_subplot(gs[0, 1])
        ax2.plot(epochs, train_metrics['accuracy'], label='Train', alpha=0.8, linewidth=2)
        ax2.plot(epochs, val_metrics['accuracy'], label='Validation', alpha=0.8, linewidth=2)
        ax2.set_title('Training and Validation Accuracy')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Accuracy')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # Loss components
        ax3 = fig.add_subplot(gs[1, :])
        loss_components = ['pred_loss', 'dp_loss', 'eo_loss', 'adv_loss']
        component_labels = ['Prediction', 'Demographic Parity', 'Equalized Odds', 'Adversarial']
        
        for component, label in zip(loss_components, component_labels):
            if component in train_metrics and len(train_metrics[component]) > 0:
                ax3.plot(epochs, train_metrics[component], label=f'Train {label}', alpha=0.7)
                ax3.plot(epochs, val_metrics[component], label=f'Val {label}', alpha=0.7, linestyle='--')
        
        ax3.set_title('Loss Components Breakdown')
        ax3.set_xlabel('Epoch')
        ax3.set_ylabel('Loss')
        ax3.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        ax3.grid(True, alpha=0.3)
        
        # Learning rate schedule
        ax4 = fig.add_subplot(gs[2, 0])
        ax4.plot(epochs, learning_rates, color='red', linewidth=2)
        ax4.set_title('Learning Rate Schedule')
        ax4.set_xlabel('Epoch')
        ax4.set_ylabel('Learning Rate')
        ax4.set_yscale('log')
        ax4.grid(True, alpha=0.3)
        
        # Gradient norm (if available)
        ax5 = fig.add_subplot(gs[2, 1])
        # Placeholder for gradient norms - would need to be tracked during training
        ax5.text(0.5, 0.5, 'Gradient Norm\n(Would be tracked\nduring training)', 
                ha='center', va='center', transform=ax5.transAxes, fontsize=14)
        ax5.set_title('Gradient L2 Norm')
        ax5.set_xlabel('Epoch')
        ax5.set_ylabel('Gradient Norm')
        
        plt.suptitle('NeuroXAI-Fuse Training Dynamics', fontsize=20, y=0.98)
        plt.savefig(f"{self.save_dir}/training_dynamics.png", dpi=self.dpi, bbox_inches='tight')
        plt.close()
    
    def create_interactive_dashboard(self, evaluation_results):
        """Create interactive Plotly dashboard"""
        # Extract data
        labels = evaluation_results['labels']
        predictions = evaluation_results['predictions']
        probabilities = evaluation_results['probabilities']
        concepts = evaluation_results['concepts']
        responsibilities = evaluation_results['responsibilities']
        
        # Create subplots
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Confusion Matrix', 'Concept Activations', 
                          'Uncertainty Distribution', 'Feature Space'),
            specs=[[{"type": "heatmap"}, {"type": "heatmap"}],
                   [{"type": "histogram"}, {"type": "scatter"}]]
        )
        
        # Confusion matrix
        cm = confusion_matrix(labels, predictions)
        fig.add_trace(
            go.Heatmap(z=cm, x=['CN', 'MCI', 'AD'], y=['CN', 'MCI', 'AD'],
                      colorscale='Blues', showscale=False),
            row=1, col=1
        )
        
        # Concept activations (simplified)
        concept_names_short = [name[:10] + '...' if len(name) > 10 else name 
                              for name in ['Hip.Atr', 'Cort.Th', 'Amy.Bur', 'Tau.Pat', 'DMN.Con']]
        avg_concepts = np.mean(concepts[:, :5], axis=0)  # Show first 5 concepts
        
        fig.add_trace(
            go.Heatmap(z=[avg_concepts], x=concept_names_short, y=['Average'],
                      colorscale='RdYlBu_r', showscale=False),
            row=1, col=2
        )
        
        # Uncertainty distribution
        confidences = np.max(probabilities, axis=1)
        fig.add_trace(
            go.Histogram(x=confidences, nbinsx=30, name='Confidence', showlegend=False),
            row=2, col=1
        )
        
        # Feature space (use first 2 PCA components as placeholder)
        from sklearn.decomposition import PCA
        pca = PCA(n_components=2)
        features_2d = pca.fit_transform(evaluation_results['features'])
        
        colors = ['blue', 'orange', 'green']
        class_names = ['CN', 'MCI', 'AD']
        
        for i, (class_name, color) in enumerate(zip(class_names, colors)):
            mask = (labels == i)
            fig.add_trace(
                go.Scatter(x=features_2d[mask, 0], y=features_2d[mask, 1],
                          mode='markers', name=class_name, marker=dict(color=color),
                          showlegend=True),
                row=2, col=2
            )
        
        # Update layout
        fig.update_layout(
            title_text="NeuroXAI-Fuse Interactive Dashboard",
            title_x=0.5,
            height=800,
            showlegend=True
        )
        
        # Save interactive plot
        fig.write_html(f"{self.save_dir}/interactive_dashboard.html")
        
        return fig
    
    def generate_paper_figures(self, evaluation_results, training_metrics=None):
        """Generate all figures for the paper"""
        print("Generating figures for paper...")
        
        # Extract data
        labels = evaluation_results['labels']
        predictions = evaluation_results['predictions']
        probabilities = evaluation_results['probabilities']
        concepts = evaluation_results['concepts']
        responsibilities = evaluation_results['responsibilities']
        features = evaluation_results['features']
        
        # Concept names
        concept_names = [
            "Hippocampal Atrophy", "Cortical Thinning", "Amyloid Burden",
            "Tau Pathology", "DMN Connectivity", "Executive Network",
            "Ventricular Enlargement", "Temporal Lobe Volume", "Parietal Hypometabolism",
            "Frontal Hypometabolism", "Memory Network", "Language Network",
            "Visual Network", "Sensorimotor Network", "Attention Network"
        ]
        
        # Generate all plots
        self.plot_roc_curves(labels, probabilities)
        self.plot_confusion_matrix(labels, predictions)
        self.plot_fairness_analysis(evaluation_results)
        self.plot_concept_analysis(concepts, labels, concept_names)
        self.plot_uncertainty_analysis(probabilities, labels, responsibilities)
        self.plot_feature_analysis(features, labels, method='tsne')
        self.plot_feature_analysis(features, labels, method='pca')
        
        if training_metrics:
            self.plot_training_dynamics(training_metrics)
        
        # Create interactive dashboard
        self.create_interactive_dashboard(evaluation_results)
        
        print(f"All figures saved to: {self.save_dir}")

# Example usage
if __name__ == "__main__":
    # Create visualizer
    visualizer = NeuroXAIVisualizer(save_dir="./plots")
    
    # Generate dummy evaluation results for demonstration
    n_samples = 500
    np.random.seed(42)
    
    dummy_results = {
        'labels': np.random.randint(0, 3, n_samples),
        'predictions': np.random.randint(0, 3, n_samples),
        'probabilities': np.random.dirichlet([1, 1, 1], n_samples),
        'concepts': np.random.rand(n_samples, 15),
        'responsibilities': np.random.beta(2, 2, n_samples),
        'features': np.random.randn(n_samples, 512),
        'fairness': {
            'demographic_parity': 0.024,
            'equalized_odds': 0.031,
            'accuracy_gap': 0.018,
            'group_metrics': {
                'young_F': {'accuracy': 0.95, 'f1': 0.94, 'count': 80},
                'young_M': {'accuracy': 0.93, 'f1': 0.92, 'count': 75},
                'middle_F': {'accuracy': 0.96, 'f1': 0.95, 'count': 90},
                'middle_M': {'accuracy': 0.94, 'f1': 0.93, 'count': 85},
                'old_F': {'accuracy': 0.92, 'f1': 0.91, 'count': 95},
                'old_M': {'accuracy': 0.91, 'f1': 0.90, 'count': 75}
            }
        }
    }
    
    # Generate figures
    visualizer.generate_paper_figures(dummy_results)
    print("Demo figures generated successfully!")
