import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional
import math

class SpatialAttention3D(nn.Module):
    """3D Spatial Attention Module for structural MRI and PET data"""
    def __init__(self, in_channels: int):
        super(SpatialAttention3D, self).__init__()
        self.conv1 = nn.Conv3d(in_channels, in_channels // 8, 1)
        self.conv2 = nn.Conv3d(in_channels // 8, 1, 1)
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        # x shape: (B, C, D, H, W)
        attention = self.conv1(x)
        attention = F.relu(attention)
        attention = self.conv2(attention)
        attention = self.sigmoid(attention)
        return x * attention

class SpatialStreamEncoder(nn.Module):
    """Spatial Stream for processing sMRI and PET data"""
    def __init__(self, input_channels: int = 2, hidden_dim: int = 512):
        super(SpatialStreamEncoder, self).__init__()
        
        # 3D ResNet-like architecture
        self.conv1 = nn.Conv3d(input_channels, 64, kernel_size=7, stride=2, padding=3)
        self.bn1 = nn.BatchNorm3d(64)
        self.pool1 = nn.MaxPool3d(kernel_size=3, stride=2, padding=1)
        
        # Residual blocks
        self.layer1 = self._make_layer(64, 64, 2)
        self.layer2 = self._make_layer(64, 128, 2, stride=2)
        self.layer3 = self._make_layer(128, 256, 2, stride=2)
        self.layer4 = self._make_layer(256, 512, 2, stride=2)
        
        # Spatial attention
        self.spatial_attention = SpatialAttention3D(512)
        
        # Global average pooling
        self.global_pool = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Linear(512, hidden_dim)
        
    def _make_layer(self, in_channels, out_channels, blocks, stride=1):
        layers = []
        layers.append(ResidualBlock3D(in_channels, out_channels, stride))
        for _ in range(1, blocks):
            layers.append(ResidualBlock3D(out_channels, out_channels))
        return nn.Sequential(*layers)
    
    def forward(self, x):
        # x shape: (B, 2, D, H, W) - sMRI and PET
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.pool1(x)
        
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        # Apply spatial attention
        x = self.spatial_attention(x)
        
        # Global pooling and projection
        x = self.global_pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        
        return x

class ResidualBlock3D(nn.Module):
    """3D Residual Block"""
    def __init__(self, in_channels, out_channels, stride=1):
        super(ResidualBlock3D, self).__init__()
        self.conv1 = nn.Conv3d(in_channels, out_channels, 3, stride, 1)
        self.bn1 = nn.BatchNorm3d(out_channels)
        self.conv2 = nn.Conv3d(out_channels, out_channels, 3, 1, 1)
        self.bn2 = nn.BatchNorm3d(out_channels)
        
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv3d(in_channels, out_channels, 1, stride),
                nn.BatchNorm3d(out_channels)
            )
    
    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out

class TemporalStreamEncoder(nn.Module):
    """Temporal Stream for processing fMRI time series using Transformer"""
    def __init__(self, input_dim: int = 200, hidden_dim: int = 512, num_heads: int = 8, num_layers: int = 6):
        super(TemporalStreamEncoder, self).__init__()
        
        self.input_projection = nn.Linear(input_dim, hidden_dim)
        self.positional_encoding = PositionalEncoding(hidden_dim)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=num_heads,
            dim_feedforward=hidden_dim * 4,
            dropout=0.1,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers)
        
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(hidden_dim, hidden_dim)
        
    def forward(self, x):
        # x shape: (B, num_regions, time_points)
        B, num_regions, time_points = x.shape
        
        # Reshape for transformer: (B * num_regions, time_points, 1)
        x = x.view(B * num_regions, time_points, 1)
        
        # Project to hidden dimension
        x = self.input_projection(x.transpose(1, 2)).transpose(1, 2)
        
        # Add positional encoding
        x = self.positional_encoding(x)
        
        # Apply transformer
        x = self.transformer(x)
        
        # Global pooling over time dimension
        x = x.transpose(1, 2)  # (B * num_regions, hidden_dim, time_points)
        x = self.global_pool(x).squeeze(-1)  # (B * num_regions, hidden_dim)
        
        # Reshape back and pool over regions
        x = x.view(B, num_regions, -1)  # (B, num_regions, hidden_dim)
        x = x.mean(dim=1)  # Pool over regions
        
        x = self.fc(x)
        return x

class PositionalEncoding(nn.Module):
    """Positional encoding for transformer"""
    def __init__(self, d_model: int, max_len: int = 5000):
        super(PositionalEncoding, self).__init__()
        
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)
    
    def forward(self, x):
        return x + self.pe[:x.size(0), :].transpose(0, 1)

class CrossModalityAttention(nn.Module):
    """Cross-modality attention mechanism"""
    def __init__(self, hidden_dim: int):
        super(CrossModalityAttention, self).__init__()
        self.hidden_dim = hidden_dim
        self.W_cross = nn.Linear(hidden_dim, hidden_dim)
        self.temperature = nn.Parameter(torch.ones(1) * math.sqrt(hidden_dim))
        
    def forward(self, h_spatial, h_temporal):
        # Compute cross-attention weights
        # h_spatial: (B, hidden_dim), h_temporal: (B, hidden_dim)
        
        # Bilinear transformation
        h_spatial_proj = self.W_cross(h_spatial)  # (B, hidden_dim)
        
        # Compute attention scores
        scores = torch.sum(h_spatial_proj * h_temporal, dim=1, keepdim=True)  # (B, 1)
        scores = scores / self.temperature
        
        # Apply softmax (here simplified for single score)
        attention_weights = torch.sigmoid(scores)  # (B, 1)
        
        # Apply attention
        attended_temporal = attention_weights * h_temporal  # (B, hidden_dim)
        
        return attended_temporal, attention_weights

class NeuroSymbolicReasoning(nn.Module):
    """Neuro-symbolic reasoning module"""
    def __init__(self, hidden_dim: int, num_concepts: int = 15, num_rules: int = 10):
        super(NeuroSymbolicReasoning, self).__init__()
        self.num_concepts = num_concepts
        self.num_rules = num_rules
        
        # Concept extraction
        self.concept_extractors = nn.ModuleList([
            nn.Linear(hidden_dim, 1) for _ in range(num_concepts)
        ])
        
        # Rule weights (learnable importance of concepts for each rule)
        self.rule_weights = nn.Parameter(torch.randn(num_rules, num_concepts))
        self.rule_biases = nn.Parameter(torch.zeros(num_rules))
        
        # Final rule combination
        self.rule_combiner = nn.Linear(num_rules, 3)  # 3 classes: CN, MCI, AD
        
        # Concept names for interpretability
        self.concept_names = [
            "Hippocampal Atrophy", "Cortical Thinning", "Amyloid Burden",
            "Tau Pathology", "DMN Connectivity", "Executive Network",
            "Ventricular Enlargement", "Temporal Lobe Volume", "Parietal Hypometabolism",
            "Frontal Hypometabolism", "Memory Network", "Language Network",
            "Visual Network", "Sensorimotor Network", "Attention Network"
        ]
        
    def forward(self, h_multimodal):
        # Extract concepts
        concepts = []
        for i, extractor in enumerate(self.concept_extractors):
            concept = torch.sigmoid(extractor(h_multimodal))
            concepts.append(concept)
        
        concepts = torch.cat(concepts, dim=1)  # (B, num_concepts)
        
        # Apply fuzzy logic rules
        rules_output = []
        for i in range(self.num_rules):
            # Weighted combination of concepts for each rule
            rule_activation = torch.sum(concepts * torch.sigmoid(self.rule_weights[i]), dim=1)
            rule_activation = rule_activation + self.rule_biases[i]
            rules_output.append(rule_activation.unsqueeze(1))
        
        rules_output = torch.cat(rules_output, dim=1)  # (B, num_rules)
        
        # Final classification
        output = self.rule_combiner(rules_output)
        
        return output, concepts, rules_output

class BiasAwareLoss(nn.Module):
    """Bias-aware loss with fairness constraints"""
    def __init__(self, alpha: float = 0.1, beta: float = 0.2, gamma: float = 0.05):
        super(BiasAwareLoss, self).__init__()
        self.alpha = alpha  # Demographic parity weight
        self.beta = beta    # Equalized odds weight
        self.gamma = gamma  # Adversarial debiasing weight
        
        # Adversarial discriminator
        self.discriminator = nn.Sequential(
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 4)  # 4 demographic groups (simplified)
        )
        
    def demographic_parity_loss(self, predictions, groups):
        """Compute demographic parity violation"""
        unique_groups = torch.unique(groups)
        if len(unique_groups) <= 1:
            return torch.tensor(0.0, device=predictions.device)
        
        group_rates = []
        for group in unique_groups:
            mask = (groups == group)
            if mask.sum() > 0:
                rate = torch.sigmoid(predictions[mask]).mean()
                group_rates.append(rate)
        
        if len(group_rates) <= 1:
            return torch.tensor(0.0, device=predictions.device)
            
        group_rates = torch.stack(group_rates)
        max_rate = group_rates.max()
        min_rate = group_rates.min()
        
        return max_rate - min_rate
    
    def equalized_odds_loss(self, predictions, labels, groups):
        """Compute equalized odds violation"""
        unique_groups = torch.unique(groups)
        if len(unique_groups) <= 1:
            return torch.tensor(0.0, device=predictions.device)
        
        eo_violations = []
        for y in [0, 1]:  # For each true label
            label_mask = (labels == y)
            if label_mask.sum() == 0:
                continue
                
            group_tpr = []
            for group in unique_groups:
                group_mask = (groups == group) & label_mask
                if group_mask.sum() > 0:
                    tpr = torch.sigmoid(predictions[group_mask]).mean()
                    group_tpr.append(tpr)
            
            if len(group_tpr) > 1:
                group_tpr = torch.stack(group_tpr)
                violation = group_tpr.max() - group_tpr.min()
                eo_violations.append(violation)
        
        return torch.stack(eo_violations).mean() if eo_violations else torch.tensor(0.0, device=predictions.device)
    
    def adversarial_loss(self, features, groups):
        """Adversarial debiasing loss"""
        group_pred = self.discriminator(features)
        return F.cross_entropy(group_pred, groups.long())
    
    def forward(self, predictions, labels, features, groups):
        # Primary prediction loss
        pred_loss = F.cross_entropy(predictions, labels.long())
        
        # Convert predictions to binary for fairness metrics
        binary_pred = predictions.argmax(dim=1)
        binary_labels = (labels > 0).long()  # CN=0, MCI/AD=1
        
        # Fairness losses
        dp_loss = self.demographic_parity_loss(binary_pred.float(), groups)
        eo_loss = self.equalized_odds_loss(binary_pred.float(), binary_labels, groups)
        adv_loss = self.adversarial_loss(features, groups)
        
        # Combined loss
        total_loss = pred_loss + self.alpha * dp_loss + self.beta * eo_loss - self.gamma * adv_loss
        
        return total_loss, {
            'pred_loss': pred_loss.item(),
            'dp_loss': dp_loss.item(),
            'eo_loss': eo_loss.item(),
            'adv_loss': adv_loss.item()
        }

class UncertaintyEstimator(nn.Module):
    """Uncertainty-aware responsibility estimation using Monte Carlo Dropout"""
    def __init__(self, hidden_dim: int):
        super(UncertaintyEstimator, self).__init__()
        self.dropout = nn.Dropout(0.5)
        self.variance_head = nn.Linear(hidden_dim, 3)  # Predict variance for each class
        
    def forward(self, x, training=True):
        if training or self.training:
            # Apply dropout during training
            x_dropped = self.dropout(x)
            variance = F.softplus(self.variance_head(x_dropped))
            return variance
        else:
            # During inference, sample multiple times
            variances = []
            for _ in range(50):  # Monte Carlo samples
                x_dropped = self.dropout(x)
                variance = F.softplus(self.variance_head(x_dropped))
                variances.append(variance)
            
            variance = torch.stack(variances).mean(dim=0)
            return variance
    
    def compute_responsibility_score(self, predictions, variance):
        """Compute responsibility score based on uncertainty"""
        # Total uncertainty (epistemic + aleatoric)
        epistemic_uncertainty = predictions.var(dim=0) if len(predictions.shape) > 1 else torch.zeros_like(predictions)
        aleatoric_uncertainty = variance.mean(dim=1) if len(variance.shape) > 1 else variance
        
        total_uncertainty = epistemic_uncertainty + aleatoric_uncertainty
        
        # Normalize to [0, 1] and invert (higher uncertainty = lower responsibility)
        max_uncertainty = total_uncertainty.max()
        if max_uncertainty > 0:
            responsibility_score = 1 - (total_uncertainty / max_uncertainty)
        else:
            responsibility_score = torch.ones_like(total_uncertainty)
        
        return responsibility_score

class NeuroXAIFuse(nn.Module):
    """Complete NeuroXAI-Fuse Framework"""
    def __init__(self, config: Dict):
        super(NeuroXAIFuse, self).__init__()
        
        self.config = config
        hidden_dim = config.get('hidden_dim', 512)
        
        # Spatial stream encoder
        self.spatial_encoder = SpatialStreamEncoder(
            input_channels=2,  # sMRI + PET
            hidden_dim=hidden_dim
        )
        
        # Temporal stream encoder
        self.temporal_encoder = TemporalStreamEncoder(
            input_dim=config.get('fmri_time_points', 200),
            hidden_dim=hidden_dim,
            num_heads=config.get('num_heads', 8),
            num_layers=config.get('num_layers', 6)
        )
        
        # Clinical data processor
        self.clinical_processor = nn.Sequential(
            nn.Linear(config.get('clinical_dim', 10), hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim // 2, hidden_dim // 2)
        )
        
        # Cross-modality attention
        self.cross_attention = CrossModalityAttention(hidden_dim)
        
        # Fusion layer
        self.fusion_weights = nn.Parameter(torch.ones(3) / 3)  # For spatial, temporal, clinical
        self.fusion_proj = nn.Linear(hidden_dim, hidden_dim)
        self.layer_norm = nn.LayerNorm(hidden_dim)
        
        # Neuro-symbolic reasoning
        self.neuro_symbolic = NeuroSymbolicReasoning(
            hidden_dim=hidden_dim,
            num_concepts=config.get('num_concepts', 15),
            num_rules=config.get('num_rules', 10)
        )
        
        # Uncertainty estimator
        self.uncertainty_estimator = UncertaintyEstimator(hidden_dim)
        
        # Bias-aware loss
        self.bias_aware_loss = BiasAwareLoss(
            alpha=config.get('alpha', 0.1),
            beta=config.get('beta', 0.2),
            gamma=config.get('gamma', 0.05)
        )
    
    def forward(self, batch, compute_loss=False):
        """
        Forward pass through the complete framework
        
        Args:
            batch: Dictionary containing:
                - smri_pet: (B, 2, D, H, W) - sMRI and PET data
                - fmri: (B, num_regions, time_points) - fMRI time series
                - clinical: (B, clinical_dim) - Clinical and genetic data
                - labels: (B,) - Ground truth labels (if compute_loss=True)
                - groups: (B,) - Demographic groups (if compute_loss=True)
        """
        
        # Extract modality-specific features
        h_spatial = self.spatial_encoder(batch['smri_pet'])
        h_temporal = self.temporal_encoder(batch['fmri'])
        h_clinical = self.clinical_processor(batch['clinical'])
        
        # Cross-modality attention
        h_temporal_attended, attention_weights = self.cross_attention(h_spatial, h_temporal)
        
        # Multimodal fusion
        fusion_weights = F.softmax(self.fusion_weights, dim=0)
        h_fused = (fusion_weights[0] * h_spatial + 
                  fusion_weights[1] * h_temporal_attended + 
                  fusion_weights[2] * h_clinical)
        
        h_multimodal = self.layer_norm(self.fusion_proj(h_fused))
        
        # Neuro-symbolic reasoning
        symbolic_output, concepts, rules = self.neuro_symbolic(h_multimodal)
        
        # Uncertainty estimation
        uncertainty = self.uncertainty_estimator(h_multimodal)
        responsibility_scores = self.uncertainty_estimator.compute_responsibility_score(
            symbolic_output, uncertainty
        )
        
        outputs = {
            'predictions': symbolic_output,
            'concepts': concepts,
            'rules': rules,
            'uncertainty': uncertainty,
            'responsibility_scores': responsibility_scores,
            'attention_weights': attention_weights,
            'features': h_multimodal
        }
        
        # Compute loss if requested
        if compute_loss and 'labels' in batch and 'groups' in batch:
            loss, loss_dict = self.bias_aware_loss(
                symbolic_output, batch['labels'], h_multimodal, batch['groups']
            )
            outputs['loss'] = loss
            outputs['loss_dict'] = loss_dict
        
        return outputs

# Configuration for the model
def get_model_config():
    return {
        'hidden_dim': 512,
        'fmri_time_points': 200,
        'clinical_dim': 10,  # Cognitive scores + genetic markers
        'num_heads': 8,
        'num_layers': 6,
        'num_concepts': 15,
        'num_rules': 10,
        'alpha': 0.1,  # Demographic parity weight
        'beta': 0.2,   # Equalized odds weight
        'gamma': 0.05  # Adversarial debiasing weight
    }

# Example usage
if __name__ == "__main__":
    # Create model
    config = get_model_config()
    model = NeuroXAIFuse(config)
    
    # Create dummy batch
    batch = {
        'smri_pet': torch.randn(4, 2, 64, 64, 64),  # Batch of 4
        'fmri': torch.randn(4, 116, 200),  # 116 AAL regions, 200 time points
        'clinical': torch.randn(4, 10),  # Clinical features
        'labels': torch.randint(0, 3, (4,)),  # CN=0, MCI=1, AD=2
        'groups': torch.randint(0, 4, (4,))  # Demographic groups
    }
    
    # Forward pass
    outputs = model(batch, compute_loss=True)
    
    print(f"Predictions shape: {outputs['predictions'].shape}")
    print(f"Concepts shape: {outputs['concepts'].shape}")
    print(f"Rules shape: {outputs['rules'].shape}")
    print(f"Loss: {outputs['loss'].item():.4f}")
    print(f"Loss components: {outputs['loss_dict']}")
