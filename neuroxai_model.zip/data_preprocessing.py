import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
import nibabel as nib
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
import scipy.io as sio
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

class ADNIDataPreprocessor:
    """Data preprocessor for ADNI dataset"""
    
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.scaler_clinical = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.group_encoder = LabelEncoder()
        
    def load_neuroimaging_data(self, subject_id: str, modality: str) -> np.ndarray:
        """Load neuroimaging data for a specific subject and modality"""
        file_path = os.path.join(self.data_dir, modality, f"{subject_id}_{modality}.nii.gz")
        
        if not os.path.exists(file_path):
            # Create dummy data if file doesn't exist (for demonstration)
            if modality in ['smri', 'pet']:
                return np.random.randn(128, 128, 128).astype(np.float32)
            elif modality == 'fmri':
                return np.random.randn(116, 200).astype(np.float32)
        
        try:
            if modality in ['smri', 'pet']:
                # Load structural/PET data
                img = nib.load(file_path)
                data = img.get_fdata().astype(np.float32)
                
                # Resize to standard dimensions if needed
                target_shape = (128, 128, 128)
                if data.shape != target_shape:
                    from scipy.ndimage import zoom
                    zoom_factors = [t/s for t, s in zip(target_shape, data.shape)]
                    data = zoom(data, zoom_factors)
                
                return data
                
            elif modality == 'fmri':
                # Load fMRI time series (assumed to be preprocessed ROI signals)
                data = np.load(file_path.replace('.nii.gz', '_timeseries.npy'))
                if data.shape[0] != 116:  # AAL atlas regions
                    data = np.random.randn(116, 200).astype(np.float32)
                return data
                
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            # Return dummy data
            if modality in ['smri', 'pet']:
                return np.random.randn(128, 128, 128).astype(np.float32)
            elif modality == 'fmri':
                return np.random.randn(116, 200).astype(np.float32)
    
    def normalize_imaging_data(self, data: np.ndarray, modality: str) -> np.ndarray:
        """Normalize imaging data according to paper specifications"""
        if modality in ['smri', 'pet']:
            # Brain extraction mask (simplified)
            brain_mask = data > (np.mean(data) + 0.5 * np.std(data))
            
            # Normalize within brain mask
            brain_voxels = data[brain_mask]
            if len(brain_voxels) > 0:
                mean_val = np.mean(brain_voxels)
                std_val = np.std(brain_voxels)
                if std_val > 0:
                    data = (data - mean_val) / std_val
                    data = data * brain_mask.astype(np.float32)
            
        elif modality == 'fmri':
            # Temporal filtering and standardization
            # Apply bandpass filter (0.01-0.1 Hz) - simplified
            from scipy.signal import butter, filtfilt
            
            fs = 0.5  # Sampling frequency (TR = 2s)
            nyquist = fs / 2
            low = 0.01 / nyquist
            high = 0.1 / nyquist
            
            try:
                b, a = butter(4, [low, high], btype='band')
                for roi in range(data.shape[0]):
                    data[roi, :] = filtfilt(b, a, data[roi, :])
            except:
                pass  # Skip filtering if error
            
            # Z-score normalization
            data = (data - np.mean(data, axis=1, keepdims=True)) / (np.std(data, axis=1, keepdims=True) + 1e-8)
        
        return data
    
    def create_dummy_clinical_data(self, n_subjects: int) -> pd.DataFrame:
        """Create dummy clinical data for demonstration"""
        np.random.seed(42)
        
        data = {
            'subject_id': [f'sub_{i:04d}' for i in range(n_subjects)],
            'age': np.random.normal(72, 8, n_subjects),
            'education': np.random.normal(14, 3, n_subjects),
            'mmse': np.random.normal(26, 4, n_subjects),
            'adas_cog': np.random.normal(12, 6, n_subjects),
            'cdr': np.random.choice([0, 0.5, 1, 2], n_subjects, p=[0.3, 0.4, 0.2, 0.1]),
            'apoe4': np.random.choice([0, 1], n_subjects, p=[0.7, 0.3]),
            'gender': np.random.choice(['M', 'F'], n_subjects, p=[0.45, 0.55]),
            'diagnosis': np.random.choice(['CN', 'MCI', 'AD'], n_subjects, p=[0.3, 0.4, 0.3])
        }
        
        # Adjust clinical scores based on diagnosis
        for i in range(n_subjects):
            if data['diagnosis'][i] == 'CN':
                data['mmse'][i] = np.clip(np.random.normal(28, 2), 24, 30)
                data['adas_cog'][i] = np.clip(np.random.normal(8, 3), 0, 15)
            elif data['diagnosis'][i] == 'MCI':
                data['mmse'][i] = np.clip(np.random.normal(25, 3), 20, 29)
                data['adas_cog'][i] = np.clip(np.random.normal(15, 5), 5, 30)
            else:  # AD
                data['mmse'][i] = np.clip(np.random.normal(20, 4), 10, 26)
                data['adas_cog'][i] = np.clip(np.random.normal(25, 8), 15, 50)
        
        return pd.DataFrame(data)
    
    def demographic_correction(self, clinical_data: pd.DataFrame) -> pd.DataFrame:
        """Apply demographic correction to cognitive scores"""
        corrected_data = clinical_data.copy()
        
        # Age and education corrections for MMSE and ADAS-Cog
        age_mean = clinical_data['age'].mean()
        edu_mean = clinical_data['education'].mean()
        
        # Simple linear corrections (in practice, use normative data)
        age_correction = (clinical_data['age'] - age_mean) * 0.1
        edu_correction = (clinical_data['education'] - edu_mean) * 0.2
        
        corrected_data['mmse_corrected'] = (
            clinical_data['mmse'] - age_correction + edu_correction
        )
        corrected_data['adas_cog_corrected'] = (
            clinical_data['adas_cog'] + age_correction - edu_correction
        )
        
        return corrected_data

class NeuroXAIDataset(Dataset):
    """PyTorch Dataset for NeuroXAI-Fuse"""
    
    def __init__(self, 
                 data_dir: str,
                 clinical_data: pd.DataFrame,
                 split: str = 'train',
                 transform=None):
        
        self.data_dir = data_dir
        self.clinical_data = clinical_data
        self.split = split
        self.transform = transform
        
        # Prepare clinical features
        self.prepare_clinical_features()
        
        # Create demographic groups
        self.create_demographic_groups()
    
    def prepare_clinical_features(self):
        """Prepare clinical features for model input"""
        # Select relevant clinical features
        clinical_features = [
            'age', 'education', 'mmse_corrected', 'adas_cog_corrected', 
            'cdr', 'apoe4'
        ]
        
        # Add gender encoding
        self.clinical_data['gender_encoded'] = (self.clinical_data['gender'] == 'M').astype(int)
        clinical_features.append('gender_encoded')
        
        # Standardize clinical features
        scaler = StandardScaler()
        clinical_matrix = scaler.fit_transform(self.clinical_data[clinical_features])
        
        # Add polynomial features for richer representation
        from sklearn.preprocessing import PolynomialFeatures
        poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
        clinical_matrix = poly.fit_transform(clinical_matrix)
        
        # Select top features to maintain dimensionality
        if clinical_matrix.shape[1] > 10:
            from sklearn.feature_selection import SelectKBest, f_classif
            # Create labels for feature selection
            labels = LabelEncoder().fit_transform(self.clinical_data['diagnosis'])
            selector = SelectKBest(f_classif, k=10)
            clinical_matrix = selector.fit_transform(clinical_matrix, labels)
        
        self.clinical_features = clinical_matrix
        
        # Encode labels
        self.labels = LabelEncoder().fit_transform(self.clinical_data['diagnosis'])
    
    def create_demographic_groups(self):
        """Create demographic groups for fairness evaluation"""
        # Create age groups
        age_groups = pd.cut(self.clinical_data['age'], 
                           bins=[0, 65, 75, 100], 
                           labels=['young', 'middle', 'old'])
        
        # Combine age and gender for demographic groups
        demo_groups = []
        for age_group, gender in zip(age_groups, self.clinical_data['gender']):
            demo_groups.append(f"{age_group}_{gender}")
        
        # Encode demographic groups
        self.demographic_groups = LabelEncoder().fit_transform(demo_groups)
    
    def __len__(self):
        return len(self.clinical_data)
    
    def __getitem__(self, idx):
        subject_id = self.clinical_data.iloc[idx]['subject_id']
        
        # Load neuroimaging data
        preprocessor = ADNIDataPreprocessor(self.data_dir)
        
        # Load and normalize sMRI
        smri_data = preprocessor.load_neuroimaging_data(subject_id, 'smri')
        smri_data = preprocessor.normalize_imaging_data(smri_data, 'smri')
        
        # Load and normalize PET
        pet_data = preprocessor.load_neuroimaging_data(subject_id, 'pet')
        pet_data = preprocessor.normalize_imaging_data(pet_data, 'pet')
        
        # Combine sMRI and PET
        smri_pet = np.stack([smri_data, pet_data], axis=0)  # (2, H, W, D)
        
        # Load and normalize fMRI
        fmri_data = preprocessor.load_neuroimaging_data(subject_id, 'fmri')
        fmri_data = preprocessor.normalize_imaging_data(fmri_data, 'fmri')
        
        # Get clinical features
        clinical_features = self.clinical_features[idx]
        
        # Get labels and groups
        label = self.labels[idx]
        group = self.demographic_groups[idx]
        
        # Convert to tensors
        sample = {
            'smri_pet': torch.FloatTensor(smri_pet),
            'fmri': torch.FloatTensor(fmri_data),
            'clinical': torch.FloatTensor(clinical_features),
            'labels': torch.LongTensor([label])[0],
            'groups': torch.LongTensor([group])[0],
            'subject_id': subject_id
        }
        
        if self.transform:
            sample = self.transform(sample)
        
        return sample

def create_data_loaders(data_dir: str, 
                       batch_size: int = 16,
                       n_subjects: int = 1000,
                       test_size: float = 0.2,
                       val_size: float = 0.1) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """Create train, validation, and test data loaders"""
    
    # Create dummy clinical data (replace with actual data loading)
    preprocessor = ADNIDataPreprocessor(data_dir)
    clinical_data = preprocessor.create_dummy_clinical_data(n_subjects)
    clinical_data = preprocessor.demographic_correction(clinical_data)
    
    # Split data
    train_data, temp_data = train_test_split(
        clinical_data, test_size=test_size + val_size, 
        stratify=clinical_data['diagnosis'], random_state=42
    )
    
    val_data, test_data = train_test_split(
        temp_data, test_size=test_size / (test_size + val_size),
        stratify=temp_data['diagnosis'], random_state=42
    )
    
    print(f"Dataset splits:")
    print(f"Train: {len(train_data)} subjects")
    print(f"Validation: {len(val_data)} subjects") 
    print(f"Test: {len(test_data)} subjects")
    
    # Create datasets
    train_dataset = NeuroXAIDataset(data_dir, train_data, split='train')
    val_dataset = NeuroXAIDataset(data_dir, val_data, split='val')
    test_dataset = NeuroXAIDataset(data_dir, test_data, split='test')
    
    # Create data loaders
    train_loader = DataLoader(
        train_dataset, 
        batch_size=batch_size, 
        shuffle=True, 
        num_workers=4,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset, 
        batch_size=batch_size, 
        shuffle=False, 
        num_workers=4,
        pin_memory=True
    )
    
    test_loader = DataLoader(
        test_dataset, 
        batch_size=batch_size, 
        shuffle=False, 
        num_workers=4,
        pin_memory=True
    )
    
    return train_loader, val_loader, test_loader

class DataAugmentation:
    """Data augmentation for neuroimaging data"""
    
    def __init__(self, prob: float = 0.5):
        self.prob = prob
    
    def __call__(self, sample):
        if np.random.random() < self.prob:
            sample = self.apply_augmentation(sample)
        return sample
    
    def apply_augmentation(self, sample):
        """Apply random augmentations"""
        # Gaussian noise
        if np.random.random() < 0.3:
            noise_level = 0.02
            sample['smri_pet'] += torch.randn_like(sample['smri_pet']) * noise_level
        
        # Random rotation (simplified - only for demonstration)
        if np.random.random() < 0.2:
            # Apply small rotation to imaging data
            angle = np.random.uniform(-5, 5) * np.pi / 180
            # In practice, use proper 3D rotation
            pass
        
        # Intensity scaling
        if np.random.random() < 0.3:
            scale_factor = np.random.uniform(0.9, 1.1)
            sample['smri_pet'] *= scale_factor
        
        return sample

# Utility functions for data analysis
def analyze_dataset_distribution(clinical_data: pd.DataFrame):
    """Analyze and visualize dataset distribution"""
    print("Dataset Distribution Analysis:")
    print("=" * 50)
    
    # Diagnosis distribution
    diagnosis_counts = clinical_data['diagnosis'].value_counts()
    print(f"\nDiagnosis Distribution:")
    for diag, count in diagnosis_counts.items():
        print(f"  {diag}: {count} ({count/len(clinical_data)*100:.1f}%)")
    
    # Age distribution by diagnosis
    print(f"\nAge Distribution by Diagnosis:")
    age_stats = clinical_data.groupby('diagnosis')['age'].agg(['mean', 'std', 'min', 'max'])
    print(age_stats)
    
    # Gender distribution
    print(f"\nGender Distribution:")
    gender_diag = pd.crosstab(clinical_data['diagnosis'], clinical_data['gender'])
    print(gender_diag)
    
    # Cognitive scores by diagnosis
    print(f"\nCognitive Scores by Diagnosis:")
    cog_stats = clinical_data.groupby('diagnosis')[['mmse', 'adas_cog']].agg(['mean', 'std'])
    print(cog_stats)
    
    return diagnosis_counts, age_stats, gender_diag, cog_stats

# Example usage
if __name__ == "__main__":
    # Set data directory (replace with actual path)
    data_dir = "./data/ADNI"
    
    # Create data loaders
    train_loader, val_loader, test_loader = create_data_loaders(
        data_dir=data_dir,
        batch_size=8,
        n_subjects=500  # Smaller for demonstration
    )
    
    print(f"Created data loaders:")
    print(f"Train batches: {len(train_loader)}")
    print(f"Val batches: {len(val_loader)}")
    print(f"Test batches: {len(test_loader)}")
    
    # Test data loading
    sample_batch = next(iter(train_loader))
    print(f"\nSample batch shapes:")
    for key, value in sample_batch.items():
        if isinstance(value, torch.Tensor):
            print(f"  {key}: {value.shape}")
        else:
            print(f"  {key}: {type(value)}")
    
    # Analyze dataset
    preprocessor = ADNIDataPreprocessor(data_dir)
    clinical_data = preprocessor.create_dummy_clinical_data(500)
    clinical_data = preprocessor.demographic_correction(clinical_data)
    
    analyze_dataset_distribution(clinical_data)
