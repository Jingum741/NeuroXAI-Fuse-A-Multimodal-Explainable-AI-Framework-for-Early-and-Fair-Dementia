import torch
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, precision_recall_curve,
    confusion_matrix, classification_report
)
from sklearn.calibration import calibration_curve
import scipy.stats as stats
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

class FairnessMetrics:
    """Calculate fairness metrics across demographic groups"""
    
    def __init__(self):
        self.group_names = {0: 'young_F', 1: 'young_M', 2: 'middle_F', 3: 'middle_M', 
                           4: 'old_F', 5: 'old_M'}
    
    def demographic_parity_difference(self, y_pred, groups):
        """Calculate demographic parity difference"""
        unique_groups = np.unique(groups)
        group_rates = []
        
        for group in unique_groups:
            mask = (groups == group)
            if mask.sum() > 0:
                rate = np.mean(y_pred[mask])
                group_rates.append(rate)
        
        return np.max(group_rates) - np.min(group_rates) if len(group_rates) > 1 else 0.0
    
    def equalized_odds_difference(self, y_true, y_pred, groups):
        """Calculate equalized odds difference"""
        unique_groups = np.unique(groups)
        tpr_differences = []
        fpr_differences = []
        
        for y_val in [0, 1]:
            label_mask = (y_true == y_val)
            if label_mask.sum() == 0:
                continue
            
            group_rates = []
            for group in unique_groups:
                group_mask = (groups == group) & label_mask
                if group_mask.sum() > 0:
                    rate = np.mean(y_pred[group_mask])
                    group_rates.append(rate)
            
            if len(group_rates) > 1:
                if y_val == 1:
                    tpr_differences.append(np.max(group_rates) - np.min(group_rates))
                else:
                    fpr_differences.append(np.max(group_rates) - np.min(group_rates))
        
        return np.mean(tpr_differences + fpr_differences)
    
    def individual_fairness_violation(self, features, predictions, k=5):
        """Calculate individual fairness violation (similar individuals should have similar outcomes)"""
        from sklearn.neighbors import NearestNeighbors
        
        # Find k nearest neighbors for each sample
        nbrs = NearestNeighbors(n_neighbors=k+1, algorithm='ball_tree').fit(features)
        distances, indices = nbrs.kneighbors(features)
        
        violations = []
        for i in range(len(features)):
            # Get predictions for neighbors (excluding self)
            neighbor_preds = predictions[indices[i][1:]]
            own_pred = predictions[i]
            
            # Calculate prediction differences with neighbors
            pred_diffs = np.abs(neighbor_preds - own_pred)
            avg_violation = np.mean(pred_diffs)
            violations.append(avg_violation)
        
        return np.mean(violations)
    
    def calculate_all_fairness_metrics(self, y_true, y_pred, groups, features=None):
        """Calculate comprehensive fairness metrics"""
        # Convert multi-class to binary for fairness analysis
        y_true_binary = (y_true > 0).astype(int)  # CN=0, MCI/AD=1
        y_pred_binary = (y_pred > 0).astype(int)
        
        metrics = {
            'demographic_parity': self.demographic_parity_difference(y_pred_binary, groups),
            'equalized_odds': self.equalized_odds_difference(y_true_binary, y_pred_binary, groups)
        }
        
        if features is not None:
            metrics['individual_fairness'] = self.individual_fairness_violation(features, y_pred_binary)
        
        # Group-wise performance metrics
        group_metrics = {}
        unique_groups = np.unique(groups)
        
        for group in unique_groups:
            mask = (groups == group)
            if mask.sum() > 0:
                group_name = self.group_names.get(group, f'group_{group}')
                group_metrics[group_name] = {
                    'accuracy': accuracy_score(y_true[mask], y_pred[mask]),
                    'precision': precision_score(y_true[mask], y_pred[mask], average='weighted', zero_division=0),
                    'recall': recall_score(y_true[mask], y_pred[mask], average='weighted', zero_division=0),
                    'f1': f1_score(y_true[mask], y_pred[mask], average='weighted', zero_division=0),
                    'count': mask.sum()
                }
        
        metrics['group_metrics'] = group_metrics
        
        # Calculate fairness gaps
        accuracies = [group_metrics[g]['accuracy'] for g in group_metrics]
        metrics['accuracy_gap'] = np.max(accuracies) - np.min(accuracies)
        
        return metrics

class InterpretabilityMetrics:
    """Calculate interpretability and explainability metrics"""
    
    def __init__(self, concept_names: List[str]):
        self.concept_names = concept_names
    
    def concept_consistency(self, concepts_batch, labels_batch):
        """Calculate consistency of concept activations within diagnostic groups"""
        unique_labels = np.unique(labels_batch)
        consistency_scores = []
        
        for label in unique_labels:
            mask = (labels_batch == label)
            if mask.sum() <= 1:
                continue
            
            label_concepts = concepts_batch[mask]
            # Calculate within-group consistency (low variance = high consistency)
            concept_vars = np.var(label_concepts, axis=0)
            consistency = 1 / (1 + concept_vars.mean())  # Convert variance to consistency
            consistency_scores.append(consistency)
        
        return np.mean(consistency_scores) if consistency_scores else 0.0
    
    def rule_stability(self, rules_batch, labels_batch):
        """Calculate stability of symbolic rules"""
        unique_labels = np.unique(labels_batch)
        stability_scores = []
        
        for label in unique_labels:
            mask = (labels_batch == label)
            if mask.sum() <= 1:
                continue
            
            label_rules = rules_batch[mask]
            # Calculate rule activation stability
            rule_vars = np.var(label_rules, axis=0)
            stability = 1 / (1 + rule_vars.mean())
            stability_scores.append(stability)
        
        return np.mean(stability_scores) if stability_scores else 0.0
    
    def clinical_relevance_score(self, concepts_batch, labels_batch):
        """Calculate clinical relevance based on concept-diagnosis correlations"""
        correlations = []
        
        for i, concept_name in enumerate(self.concept_names):
            concept_values = concepts_batch[:, i]
            
            # Calculate correlation with diagnosis severity (CN=0, MCI=1, AD=2)
            correlation, p_value = stats.pearsonr(concept_values, labels_batch)
            
            # Weight by significance and known clinical relevance
            clinical_weight = self._get_clinical_weight(concept_name)
            relevance = abs(correlation) * clinical_weight * (1 if p_value < 0.05 else 0.5)
            correlations.append(relevance)
        
        return np.mean(correlations)
    
    def _get_clinical_weight(self, concept_name: str) -> float:
        """Get clinical importance weight for concept"""
        # Higher weights for more clinically relevant concepts
        important_concepts = {
            'hippocampal atrophy': 1.0,
            'cortical thinning': 0.9,
            'amyloid burden': 1.0,
            'tau pathology': 0.9,
            'dmn connectivity': 0.8,
            'ventricular enlargement': 0.7,
            'temporal lobe volume': 0.8,
            'memory network': 0.9
        }
        
        concept_lower = concept_name.lower()
        for key, weight in important_concepts.items():
            if key in concept_lower:
                return weight
        
        return 0.6  # Default weight

class UncertaintyCalibration:
    """Evaluate uncertainty calibration and responsibility estimation"""
    
    def expected_calibration_error(self, confidences, accuracies, n_bins=10):
        """Calculate Expected Calibration Error (ECE)"""
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        ece = 0
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            in_bin = (confidences > bin_lower) & (confidences <= bin_upper)
            prop_in_bin = in_bin.mean()
            
            if prop_in_bin > 0:
                accuracy_in_bin = accuracies[in_bin].mean()
                avg_confidence_in_bin = confidences[in_bin].mean()
                ece += np.abs(avg_confidence_in_bin - accuracy_in_bin) * prop_in_bin
        
        return ece
    
    def maximum_calibration_error(self, confidences, accuracies, n_bins=10):
        """Calculate Maximum Calibration Error (MCE)"""
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        mce = 0
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            in_bin = (confidences > bin_lower) & (confidences <= bin_upper)
            prop_in_bin = in_bin.mean()
            
            if prop_in_bin > 0:
                accuracy_in_bin = accuracies[in_bin].mean()
                avg_confidence_in_bin = confidences[in_bin].mean()
                mce = max(mce, np.abs(avg_confidence_in_bin - accuracy_in_bin))
        
        return mce
    
    def brier_score(self, probabilities, labels):
        """Calculate Brier Score"""
        # Convert labels to one-hot encoding
        n_classes = probabilities.shape[1]
        labels_onehot = np.eye(n_classes)[labels]
        
        # Brier score
        brier = np.mean(np.sum((probabilities - labels_onehot) ** 2, axis=1))
        return brier
    
    def reliability_diagram_data(self, confidences, accuracies, n_bins=10):
        """Generate data for reliability diagram"""
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        bin_confidences = []
        bin_accuracies = []
        bin_counts = []
        
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            in_bin = (confidences > bin_lower) & (confidences <= bin_upper)
            prop_in_bin = in_bin.mean()
            
            if prop_in_bin > 0:
                accuracy_in_bin = accuracies[in_bin].mean()
                avg_confidence_in_bin = confidences[in_bin].mean()
                count_in_bin = in_bin.sum()
                
                bin_confidences.append(avg_confidence_in_bin)
                bin_accuracies.append(accuracy_in_bin)
                bin_counts.append(count_in_bin)
            else:
                bin_confidences.append(0)
                bin_accuracies.append(0)
                bin_counts.append(0)
        
        return np.array(bin_confidences), np.array(bin_accuracies), np.array(bin_counts)

class ComprehensiveEvaluator:
    """Main evaluation class combining all metrics"""
    
    def __init__(self, concept_names: List[str]):
        self.fairness_metrics = FairnessMetrics()
        self.interpretability_metrics = InterpretabilityMetrics(concept_names)
        self.uncertainty_calibration = UncertaintyCalibration()
    
    def evaluate_model(self, model, test_loader, device='cuda'):
        """Comprehensive model evaluation"""
        model.eval()
        
        all_predictions = []
        all_labels = []
        all_groups = []
        all_probs = []
        all_concepts = []
        all_rules = []
        all_responsibilities = []
        all_features = []
        
        with torch.no_grad():
            for batch in test_loader:
                # Move to device
                for key in batch:
                    if isinstance(batch[key], torch.Tensor):
                        batch[key] = batch[key].to(device)
                
                # Forward pass
                outputs = model(batch, compute_loss=False)
                
                # Collect outputs
                predictions = outputs['predictions'].argmax(dim=1).cpu().numpy()
                labels = batch['labels'].cpu().numpy()
                groups = batch['groups'].cpu().numpy()
                probs = torch.softmax(outputs['predictions'], dim=1).cpu().numpy()
                concepts = outputs['concepts'].cpu().numpy()
                rules = outputs['rules'].cpu().numpy()
                responsibilities = outputs['responsibility_scores'].cpu().numpy()
                features = outputs['features'].cpu().numpy()
                
                all_predictions.extend(predictions)
                all_labels.extend(labels)
                all_groups.extend(groups)
                all_probs.extend(probs)
                all_concepts.extend(concepts)
                all_rules.extend(rules)
                all_responsibilities.extend(responsibilities)
                all_features.extend(features)
        
        # Convert to arrays
        all_predictions = np.array(all_predictions)
        all_labels = np.array(all_labels)
        all_groups = np.array(all_groups)
        all_probs = np.array(all_probs)
        all_concepts = np.array(all_concepts)
        all_rules = np.array(all_rules)
        all_responsibilities = np.array(all_responsibilities)
        all_features = np.array(all_features)
        
        # Calculate performance metrics
        performance_metrics = self._calculate_performance_metrics(
            all_labels, all_predictions, all_probs
        )
        
        # Calculate fairness metrics
        fairness_metrics = self.fairness_metrics.calculate_all_fairness_metrics(
            all_labels, all_predictions, all_groups, all_features
        )
        
        # Calculate interpretability metrics
        interpretability_metrics = {
            'concept_consistency': self.interpretability_metrics.concept_consistency(
                all_concepts, all_labels
            ),
            'rule_stability': self.interpretability_metrics.rule_stability(
                all_rules, all_labels
            ),
            'clinical_relevance': self.interpretability_metrics.clinical_relevance_score(
                all_concepts, all_labels
            )
        }
        
        # Calculate uncertainty metrics
        confidences = np.max(all_probs, axis=1)
        correct_predictions = (all_predictions == all_labels).astype(int)
        
        uncertainty_metrics = {
            'ece': self.uncertainty_calibration.expected_calibration_error(
                confidences, correct_predictions
            ),
            'mce': self.uncertainty_calibration.maximum_calibration_error(
                confidences, correct_predictions
            ),
            'brier_score': self.uncertainty_calibration.brier_score(
                all_probs, all_labels
            ),
            'avg_responsibility': np.mean(all_responsibilities),
            'high_confidence_ratio': np.mean(all_responsibilities > 0.8),
            'low_confidence_ratio': np.mean(all_responsibilities < 0.5)
        }
        
        # Combine all metrics
        evaluation_results = {
            'performance': performance_metrics,
            'fairness': fairness_metrics,
            'interpretability': interpretability_metrics,
            'uncertainty': uncertainty_metrics,
            'predictions': all_predictions,
            'labels': all_labels,
            'groups': all_groups,
            'probabilities': all_probs,
            'concepts': all_concepts,
            'rules': all_rules,
            'responsibilities': all_responsibilities,
            'features': all_features
        }
        
        return evaluation_results
    
    def _calculate_performance_metrics(self, labels, predictions, probabilities):
        """Calculate standard performance metrics"""
        metrics = {
            'accuracy': accuracy_score(labels, predictions),
            'precision': precision_score(labels, predictions, average='weighted', zero_division=0),
            'recall': recall_score(labels, predictions, average='weighted', zero_division=0),
            'f1_score': f1_score(labels, predictions, average='weighted', zero_division=0),
            'auc': roc_auc_score(labels, probabilities, multi_class='ovr', average='weighted')
        }
        
        # Per-class metrics
        class_names = ['CN', 'MCI', 'AD']
        for i, class_name in enumerate(class_names):
            class_mask = (labels == i)
            if class_mask.sum() > 0:
                pred_mask = (predictions == i)
                metrics[f'{class_name}_precision'] = precision_score(
                    labels == i, predictions == i, zero_division=0
                )
                metrics[f'{class_name}_recall'] = recall_score(
                    labels == i, predictions == i, zero_division=0
                )
                metrics[f'{class_name}_f1'] = f1_score(
                    labels == i, predictions == i, zero_division=0
                )
        
        return metrics
    
    def generate_evaluation_report(self, results: Dict, save_path: str = None) -> str:
        """Generate comprehensive evaluation report"""
        report = []
        report.append("="*80)
        report.append("NEUROXAI-FUSE COMPREHENSIVE EVALUATION REPORT")
        report.append("="*80)
        
        # Performance metrics
        report.append("\n📊 DIAGNOSTIC PERFORMANCE METRICS")
        report.append("-" * 50)
        perf = results['performance']
        report.append(f"Overall Accuracy: {perf['accuracy']:.4f}")
        report.append(f"Weighted Precision: {perf['precision']:.4f}")
        report.append(f"Weighted Recall: {perf['recall']:.4f}")
        report.append(f"Weighted F1-Score: {perf['f1_score']:.4f}")
        report.append(f"AUC Score: {perf['auc']:.4f}")
        
        # Per-class performance
        report.append("\nPer-Class Performance:")
        for class_name in ['CN', 'MCI', 'AD']:
            if f'{class_name}_precision' in perf:
                report.append(f"  {class_name}: Precision={perf[f'{class_name}_precision']:.4f}, "
                            f"Recall={perf[f'{class_name}_recall']:.4f}, "
                            f"F1={perf[f'{class_name}_f1']:.4f}")
        
        # Fairness metrics
        report.append("\n⚖️ FAIRNESS METRICS")
        report.append("-" * 50)
        fair = results['fairness']
        report.append(f"Demographic Parity Difference: {fair['demographic_parity']:.4f}")
        report.append(f"Equalized Odds Difference: {fair['equalized_odds']:.4f}")
        report.append(f"Accuracy Gap: {fair['accuracy_gap']:.4f}")
        if 'individual_fairness' in fair:
            report.append(f"Individual Fairness Violation: {fair['individual_fairness']:.4f}")
        
        # Group-wise performance
        report.append("\nGroup-wise Performance:")
        for group_name, metrics in fair['group_metrics'].items():
            report.append(f"  {group_name}: Accuracy={metrics['accuracy']:.4f}, "
                        f"F1={metrics['f1']:.4f}, Count={metrics['count']}")
        
        # Interpretability metrics
        report.append("\n🧠 INTERPRETABILITY METRICS")
        report.append("-" * 50)
        interp = results['interpretability']
        report.append(f"Concept Consistency: {interp['concept_consistency']:.4f}")
        report.append(f"Rule Stability: {interp['rule_stability']:.4f}")
        report.append(f"Clinical Relevance Score: {interp['clinical_relevance']:.4f}")
        
        # Uncertainty metrics
        report.append("\n🎯 UNCERTAINTY CALIBRATION METRICS")
        report.append("-" * 50)
        uncert = results['uncertainty']
        report.append(f"Expected Calibration Error: {uncert['ece']:.4f}")
        report.append(f"Maximum Calibration Error: {uncert['mce']:.4f}")
        report.append(f"Brier Score: {uncert['brier_score']:.4f}")
        report.append(f"Average Responsibility Score: {uncert['avg_responsibility']:.4f}")
        report.append(f"High Confidence Predictions: {uncert['high_confidence_ratio']:.2%}")
        report.append(f"Low Confidence Predictions: {uncert['low_confidence_ratio']:.2%}")
        
        report.append("\n" + "="*80)
        
        report_text = "\n".join(report)
        
        if save_path:
            with open(save_path, 'w') as f:
                f.write(report_text)
            print(f"Evaluation report saved to: {save_path}")
        
        return report_text

# Example usage
if __name__ == "__main__":
    # Example concept names (should match model configuration)
    concept_names = [
        "Hippocampal Atrophy", "Cortical Thinning", "Amyloid Burden",
        "Tau Pathology", "DMN Connectivity", "Executive Network",
        "Ventricular Enlargement", "Temporal Lobe Volume", "Parietal Hypometabolism",
        "Frontal Hypometabolism", "Memory Network", "Language Network",
        "Visual Network", "Sensorimotor Network", "Attention Network"
    ]
    
    # Create evaluator
    evaluator = ComprehensiveEvaluator(concept_names)
    
    print("Comprehensive evaluation system initialized.")
    print(f"Configured for {len(concept_names)} clinical concepts.")
